/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package in.jforkts.billing;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableColumnModel;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Vector;
import java.sql.SQLException;
import java.util.logging.Level;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
/**
 *
 * @author mgudd
 */
public class MyFrame extends javax.swing.JFrame {
    MyDBConnector myCon=new MyDBConnector();
 Connection con;   
PreparedStatement ps;
ResultSet rs=null;
int q,i, deleteitem;
    /**
     * Creates new form MyFrame
     */
    public MyFrame() {
        MyDBConnector myCon=new MyDBConnector();
       
        rs= myCon.getRs();
     
        initComponents();
    }

   
    
        
 @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        AD_NAME = new javax.swing.JTextField();
        PASSWORD = new javax.swing.JTextField();
        AD_ID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(520, 380));
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("AD_ID");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(70, 90, 70, 22);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel3.setText("AD_NAME");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(70, 130, 100, 22);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("PASSWORD");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(70, 170, 110, 22);

        jButton2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton2.setText("LOGIN");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(190, 300, 100, 29);

        AD_NAME.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AD_NAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AD_NAMEActionPerformed(evt);
            }
        });
        getContentPane().add(AD_NAME);
        AD_NAME.setBounds(250, 170, 200, 28);

        PASSWORD.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        PASSWORD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PASSWORDActionPerformed(evt);
            }
        });
        getContentPane().add(PASSWORD);
        PASSWORD.setBounds(250, 130, 200, 28);

        AD_ID.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AD_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AD_IDActionPerformed(evt);
            }
        });
        getContentPane().add(AD_ID);
        AD_ID.setBounds(250, 80, 120, 28);

        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setText("ADMIN DETAILS");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(120, 20, 190, 30);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\mgudd\\OneDrive\\Desktop\\New folder\\istockphoto-1279862993-170667a.jpg")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, -100, 1010, 540);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void AD_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AD_IDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AD_IDActionPerformed

    private void AD_NAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AD_NAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AD_NAMEActionPerformed

    private void PASSWORDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PASSWORDActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_PASSWORDActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     
   try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/billing","root","");
           
             ps = con.prepareStatement("insert into admin values(?,?,?)");
            
            ps.setString(1, AD_ID.getText());
            ps.setString(2, AD_NAME.getText());
            ps.setString(3, PASSWORD.getText());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "LOGIN IS SUCCESSFULLY");
            
            
        
   }
   catch (Exception ex) {
   JOptionPane.showMessageDialog(this, ex);
   }
   

   
   
   
   
      
       JFrame x= new BILL();
       x.setVisible(true);  
        
   
    
       
    }//GEN-LAST:event_jButton2ActionPerformed

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AD_ID;
    private javax.swing.JTextField AD_NAME;
    private javax.swing.JTextField PASSWORD;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables

    private void getString() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
