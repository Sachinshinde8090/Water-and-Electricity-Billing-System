/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.jforkts.billing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class MyDBConnector {
    
    Connection con;
    Statement st;
    ResultSet rs;

    public MyDBConnector() {
        
        try{
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/billing","root","");
        
        st= con.createStatement();
        rs=st.executeQuery("select * from ACCOUNT ");
        }catch(Exception e){
           System.out.println(e.toString());
               
        
        }
        
        
    }

    public Statement getStmt() {
        return st;
    }

    public ResultSet getRs() {
        return rs;
    }

    

    
    
    
}
