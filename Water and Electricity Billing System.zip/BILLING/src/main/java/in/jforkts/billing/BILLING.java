/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package in.jforkts.billing;

import javax.swing.JFrame;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class BILLING {

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
            
            JFrame myFrame=new MENU();
            myFrame.setVisible(true);
            
            
            
            }
        
        
        
        
        
        } );
        
    }
}
